
import React, { useState, useRef } from 'react';
import { SPIN_REWARDS, UserState } from '../types';
import ClaimModal from './ClaimModal';

interface LuckySpinProps {
  addDiamonds: (amount: number) => void;
  useSpin: () => boolean;
  userState: UserState;
}

const LuckySpin: React.FC<LuckySpinProps> = ({ addDiamonds, useSpin, userState }) => {
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [showClaim, setShowClaim] = useState(false);
  const [pendingReward, setPendingReward] = useState(0);
  const wheelRef = useRef<HTMLDivElement>(null);

  const handleSpin = () => {
    if (isSpinning) return;
    
    if (useSpin()) {
      setIsSpinning(true);
      const segmentSize = 360 / SPIN_REWARDS.length;
      const randomSegment = Math.floor(Math.random() * SPIN_REWARDS.length);
      const extraSpins = 5 + Math.floor(Math.random() * 5); 
      const newRotation = rotation + (extraSpins * 360) - (randomSegment * segmentSize);
      setRotation(newRotation);

      setTimeout(() => {
        setIsSpinning(false);
        const reward = SPIN_REWARDS[randomSegment];
        setPendingReward(reward.amount);
        setShowClaim(true);
      }, 4000);
    } else {
      alert("No spins left for today!");
    }
  };

  const handleClaim = () => {
    addDiamonds(pendingReward);
    setShowClaim(false);
    setPendingReward(0);
  };

  const canSpin = !isSpinning && userState.spinsRemaining > 0;

  return (
    <div className="flex flex-col items-center space-y-8 animate-fadeIn py-4">
      <div className="text-center animate-slideUp">
        <h2 className="text-2xl font-black text-gray-800 tracking-tight">Lucky Wheel</h2>
        <p className="text-gray-500 text-sm">Spin to win up to 40 diamonds!</p>
      </div>

      <div className="relative w-80 h-80 animate-slideUp stagger-1 opacity-0 fill-mode-forwards">
        {/* Glow Effect */}
        <div className="absolute inset-0 bg-indigo-500/10 blur-3xl rounded-full scale-110 animate-pulse"></div>
        
        {/* Pointer */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-5 z-20 text-indigo-600 filter drop-shadow-lg">
          <i className="fas fa-caret-down text-5xl"></i>
        </div>

        {/* Wheel Outer Border / Decoration */}
        <div className="absolute inset-[-15px] border-[12px] border-indigo-700/10 rounded-full animate-rotate-slow"></div>

        <div 
          ref={wheelRef}
          className="w-full h-full rounded-full border-[10px] border-indigo-600 shadow-[0_20px_50px_rgba(99,102,241,0.3)] relative overflow-hidden transition-transform duration-[4000ms] cubic-bezier(0.15, 0, 0.15, 1)"
          style={{ transform: `rotate(${rotation}deg)` }}
        >
          {SPIN_REWARDS.map((reward, index) => {
            const angle = (360 / SPIN_REWARDS.length) * index;
            const isEven = index % 2 === 0;
            return (
              <div 
                key={index}
                className={`absolute top-0 left-1/2 h-1/2 w-0.5 origin-bottom`}
                style={{ transform: `rotate(${angle}deg)` }}
              >
                <div 
                  className={`absolute -top-1 left-[-55px] w-[110px] h-[160px] flex flex-col items-center pt-6 ${
                    isEven ? 'bg-indigo-600 text-white' : 'bg-white text-indigo-600'
                  }`}
                  style={{ 
                    clipPath: 'polygon(50% 100%, 0 0, 100% 0)',
                    transformOrigin: 'bottom center'
                  }}
                >
                  <span className={`font-black tracking-tighter ${reward.type === 'empty' ? 'text-2xl mt-1' : 'text-sm mt-2'}`}>
                    {reward.label}
                  </span>
                  {reward.amount > 0 && (
                    <div className="mt-1 flex flex-col items-center">
                       <i className="fas fa-gem text-[10px]"></i>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
          
          {/* Center Hub */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 bg-white rounded-full border-[6px] border-indigo-600 z-10 shadow-xl flex items-center justify-center">
             <div className="w-2 h-2 bg-indigo-400 rounded-full animate-pulse"></div>
          </div>
        </div>
      </div>

      <div className="flex flex-col items-center w-full max-w-xs space-y-4 animate-slideUp stagger-2 opacity-0 fill-mode-forwards">
        <div className="bg-indigo-50 w-full px-4 py-2 rounded-2xl flex justify-between items-center border border-indigo-100">
          <span className="text-xs font-bold text-indigo-400 uppercase tracking-widest">Spins Left</span>
          <span className="text-indigo-600 font-black text-lg">{userState.spinsRemaining}</span>
        </div>
        
        <button 
          onClick={handleSpin}
          disabled={!canSpin}
          className={`w-full py-6 rounded-2xl font-black text-2xl transition-all duration-300 transform active:scale-90 ${
            !canSpin
              ? 'bg-gray-200 text-gray-400 cursor-not-allowed shadow-none'
              : 'diamond-gradient text-white hover:scale-105 hover:shadow-[0_15px_35px_rgba(99,102,241,0.5)] shadow-[0_10px_30px_rgba(99,102,241,0.3)] animate-pulse'
          }`}
          style={{ animationDuration: '3s' }}
        >
          {isSpinning ? (
            <div className="flex items-center justify-center space-x-2">
               <i className="fas fa-circle-notch animate-spin"></i>
               <span>SPINNING...</span>
            </div>
          ) : (
            <div className="flex items-center justify-center space-x-3 group">
              <span>SPIN NOW</span>
              <i className="fas fa-sync-alt text-sm opacity-50 group-hover:rotate-180 transition-transform duration-500"></i>
            </div>
          )}
        </button>
      </div>

      <ClaimModal 
        isOpen={showClaim} 
        amount={pendingReward} 
        onClaim={handleClaim} 
        title="SPIN RESULT"
      />
    </div>
  );
};

export default LuckySpin;
