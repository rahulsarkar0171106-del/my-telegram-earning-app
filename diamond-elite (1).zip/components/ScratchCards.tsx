import React, { useState, useRef, useEffect, useCallback } from 'react';
import { UserState } from '../types';
import ClaimModal from './ClaimModal';

interface ScratchCardsProps {
  addDiamonds: (amount: number) => void;
  useScratch: () => boolean;
  userState: UserState;
}

const ScratchCards: React.FC<ScratchCardsProps> = ({ addDiamonds, useScratch, userState }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isScratching, setIsScratching] = useState(false);
  const [isRevealed, setIsRevealed] = useState(false);
  const [rewardAmount, setRewardAmount] = useState(0);
  const [scratchedPercent, setScratchedPercent] = useState(0);
  const [showClaim, setShowClaim] = useState(false);

  const initCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    setIsRevealed(false);
    setScratchedPercent(0);
    const amount = Math.floor(Math.random() * 15) + 5; 
    setRewardAmount(amount);

    ctx.globalCompositeOperation = 'source-over';
    ctx.fillStyle = '#CBD5E1'; 
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    ctx.fillStyle = '#94A3B8'; 
    for(let i=0; i<100; i++) {
        ctx.fillRect(Math.random()*canvas.width, Math.random()*canvas.height, 2, 2);
    }
    
    ctx.font = 'bold 20px Arial';
    ctx.fillStyle = '#64748B';
    ctx.textAlign = 'center';
    ctx.fillText('SCRATCH HERE', canvas.width / 2, canvas.height / 2 + 7);
  }, []);

  useEffect(() => {
    initCanvas();
  }, [initCanvas]);

  const handleScratch = (e: React.MouseEvent | React.TouchEvent) => {
    if (isRevealed) return;
    
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    let x, y;
    
    if ('touches' in e) {
      x = e.touches[0].clientX - rect.left;
      y = e.touches[0].clientY - rect.top;
    } else {
      x = (e as React.MouseEvent).clientX - rect.left;
      y = (e as React.MouseEvent).clientY - rect.top;
    }

    ctx.globalCompositeOperation = 'destination-out';
    ctx.beginPath();
    ctx.arc(x, y, 20, 0, Math.PI * 2);
    ctx.fill();

    if (Math.random() > 0.8) {
        checkCompletion();
    }
  };

  const checkCompletion = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const pixels = imageData.data;
    let clearPixels = 0;
    for (let i = 3; i < pixels.length; i += 4) {
      if (pixels[i] === 0) clearPixels++;
    }
    const percent = (clearPixels / (pixels.length / 4)) * 100;
    setScratchedPercent(percent);

    if (percent > 60 && !isRevealed) {
      setIsRevealed(true);
      if (useScratch()) {
          setShowClaim(true);
      }
    }
  };

  const handleClaim = () => {
    addDiamonds(rewardAmount);
    setShowClaim(false);
  };

  const nextCard = () => {
    initCanvas();
  };

  return (
    <div className="flex flex-col items-center space-y-8 animate-fadeIn py-4">
      <div className="text-center">
        <h2 className="text-2xl font-black text-gray-800 tracking-tight">Scratch & Win</h2>
        <p className="text-gray-500 text-sm">Rub the surface to reveal your prize</p>
      </div>

      <div className="relative w-full max-w-[320px] aspect-[16/10] rounded-[2.5rem] overflow-hidden shadow-2xl bg-white border-4 border-white">
        {/* Reward Reveal Area */}
        <div className={`absolute inset-0 flex flex-col items-center justify-center diamond-gradient text-white transition-all duration-700 ${isRevealed ? 'shimmer-container' : 'scale-95 blur-sm'}`}>
          {isRevealed && (
            <>
              {/* Dynamic Sparkles */}
              <div className="sparkle-dot top-8 left-12" style={{ animationDelay: '0s' }}></div>
              <div className="sparkle-dot top-16 right-16" style={{ animationDelay: '0.4s' }}></div>
              <div className="sparkle-dot bottom-14 left-16" style={{ animationDelay: '0.8s' }}></div>
              <div className="sparkle-dot bottom-10 right-10" style={{ animationDelay: '1.2s' }}></div>
              <div className="sparkle-dot top-1/2 left-8 -translate-y-1/2" style={{ animationDelay: '0.6s' }}></div>
            </>
          )}
          
          <i className={`fas fa-gem text-6xl mb-3 filter drop-shadow-[0_10px_10px_rgba(0,0,0,0.2)] transition-all duration-700 ${isRevealed ? 'scale-110 rotate-12 opacity-100' : 'scale-50 opacity-0'}`}></i>
          
          <div className={`${isRevealed ? 'animate-winningPop' : ''}`}>
             <p className={`text-6xl font-black leading-none filter drop-shadow-md ${isRevealed ? 'text-shimmer' : 'text-white'}`}>
                {rewardAmount}
             </p>
          </div>
          
          <p className="text-sm font-black opacity-80 uppercase tracking-[0.3em] mt-2 italic">Diamonds</p>
        </div>

        {/* Scratch Surface */}
        <canvas
          ref={canvasRef}
          width={320}
          height={200}
          className="absolute inset-0 z-10 cursor-crosshair scratch-canvas touch-none"
          onMouseDown={() => setIsScratching(true)}
          onMouseUp={() => setIsScratching(false)}
          onMouseMove={(e) => isScratching && handleScratch(e)}
          onTouchStart={() => setIsScratching(true)}
          onTouchEnd={() => setIsScratching(false)}
          onTouchMove={(e) => isScratching && handleScratch(e)}
        />
      </div>

      <div className="w-full max-w-xs space-y-6">
        <div className="flex justify-between items-center bg-white px-4 py-3 rounded-2xl shadow-sm border border-gray-100">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Available Cards</span>
            <div className="flex items-center space-x-2">
                <i className="fas fa-id-card text-indigo-400 text-xs"></i>
                <span className="text-indigo-600 font-black text-lg">{userState.scratchCardsRemaining}</span>
            </div>
        </div>

        {isRevealed ? (
          <button 
            onClick={nextCard}
            disabled={userState.scratchCardsRemaining <= 0}
            className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black text-xl shadow-[0_10px_20px_rgba(79,70,229,0.3)] transition-all active:scale-95 hover:bg-indigo-700"
          >
            {userState.scratchCardsRemaining > 0 ? 'GET NEXT CARD' : 'LIMIT REACHED'}
          </button>
        ) : (
          <div className="space-y-2">
             <div className="flex justify-between text-[10px] font-black text-gray-400 uppercase tracking-[0.15em] px-1">
                <span>Scratch Progress</span>
                <span>{Math.round(scratchedPercent)}%</span>
             </div>
             <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden shadow-inner p-0.5">
                <div 
                   className="h-full diamond-gradient rounded-full transition-all duration-300" 
                   style={{ width: `${Math.min(scratchedPercent, 100)}%` }}
                ></div>
             </div>
          </div>
        )}
      </div>

      <ClaimModal 
        isOpen={showClaim} 
        amount={rewardAmount} 
        onClaim={handleClaim} 
        title="LUCKY SCRATCH!"
      />
    </div>
  );
};

export default ScratchCards;