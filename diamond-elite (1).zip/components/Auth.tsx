
import React, { useState } from 'react';
import { User } from '../types';

interface AuthProps {
  onLogin: (user: User) => void;
}

type AuthStep = 'initial' | 'picker' | 'nameEntry';

const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [step, setStep] = useState<AuthStep>('initial');
  const [isSyncing, setIsSyncing] = useState(false);
  const [selectedAccount, setSelectedAccount] = useState<{email: string, photo: string} | null>(null);
  const [userName, setUserName] = useState('');

  const startGoogleLogin = () => {
    setStep('picker');
  };

  const handleAccountSelect = (email: string, photo: string) => {
    setSelectedAccount({ email, photo });
    setStep('nameEntry');
  };

  const handleFinalLogin = () => {
    if (!userName.trim() || !selectedAccount) return;
    
    setIsSyncing(true);
    
    const mockUser: User = {
      uid: 'user_' + btoa(selectedAccount.email).substring(0, 12),
      name: userName,
      email: selectedAccount.email,
      photo: selectedAccount.photo,
      provider: 'google'
    };

    setTimeout(() => {
      setIsSyncing(false);
      onLogin(mockUser);
    }, 1500);
  };

  return (
    <div className="flex flex-col min-h-screen max-w-md mx-auto bg-[#050505] relative overflow-hidden font-sans">
      {/* Dynamic Background Elements */}
      <div className="absolute top-[-10%] left-[-20%] w-[100%] h-[40%] bg-indigo-600/20 rounded-full blur-[100px] animate-pulse pointer-events-none"></div>
      <div className="absolute bottom-[-10%] right-[-20%] w-[80%] h-[40%] bg-purple-600/10 rounded-full blur-[100px] pointer-events-none" style={{ animationDelay: '2s' }}></div>
      <div className="absolute top-[30%] right-[-10%] w-32 h-32 bg-blue-500/10 rounded-full blur-[60px] pointer-events-none"></div>

      {/* Floating Particles Simulation */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="sparkle-dot top-[15%] left-[10%]" style={{ animationDelay: '0.1s' }}></div>
        <div className="sparkle-dot top-[40%] left-[80%]" style={{ animationDelay: '1.5s' }}></div>
        <div className="sparkle-dot top-[70%] left-[20%]" style={{ animationDelay: '0.8s' }}></div>
        <div className="sparkle-dot top-[85%] left-[75%]" style={{ animationDelay: '2.2s' }}></div>
      </div>

      <div className="relative z-10 flex flex-col items-center justify-center flex-1 px-8 py-12">
        {step === 'initial' && (
          <div className="w-full flex flex-col items-center animate-fadeIn">
            {/* Branding Section */}
            <div className="relative mb-12">
              <div className="absolute inset-0 bg-indigo-500/20 blur-3xl rounded-full scale-150 animate-pulse"></div>
              <div className="relative p-10 bg-white/5 rounded-[4rem] border border-white/10 backdrop-blur-3xl animate-scaleUp shadow-[0_0_80px_rgba(99,102,241,0.2)] group">
                <i className="fas fa-gem text-indigo-400 text-8xl drop-shadow-[0_0_25px_rgba(129,140,248,0.8)] group-hover:scale-110 transition-transform duration-500"></i>
                <div className="absolute -top-2 -right-2 bg-indigo-500 w-8 h-8 rounded-full flex items-center justify-center border-2 border-black animate-bounce">
                  <i className="fas fa-shield-alt text-white text-[10px]"></i>
                </div>
              </div>
            </div>

            <div className="text-center mb-10">
              <h1 className="text-5xl font-black text-white italic tracking-tighter mb-4 uppercase tracking-[0.05em] leading-none">
                Diamond <span className="text-indigo-400">Elite</span>
              </h1>
              <div className="h-1 w-20 bg-indigo-500/50 mx-auto rounded-full mb-6"></div>
              <p className="text-gray-400 text-base font-medium max-w-[280px] mx-auto leading-relaxed">
                Unlock exclusive rewards and <span className="text-white font-bold">secure your progress</span> in our diamond cloud.
              </p>
            </div>

            {/* Benefit Highlights */}
            <div className="flex flex-wrap justify-center gap-3 mb-12">
              <div className="flex items-center space-x-2 bg-white/5 border border-white/10 px-4 py-2 rounded-2xl backdrop-blur-sm">
                <i className="fas fa-cloud-upload-alt text-indigo-400 text-xs"></i>
                <span className="text-white/70 text-[10px] font-bold uppercase tracking-widest">Auto Sync</span>
              </div>
              <div className="flex items-center space-x-2 bg-white/5 border border-white/10 px-4 py-2 rounded-2xl backdrop-blur-sm">
                <i className="fas fa-lock text-green-400 text-xs"></i>
                <span className="text-white/70 text-[10px] font-bold uppercase tracking-widest">Secure Login</span>
              </div>
              <div className="flex items-center space-x-2 bg-white/5 border border-white/10 px-4 py-2 rounded-2xl backdrop-blur-sm">
                <i className="fas fa-bolt text-yellow-400 text-xs"></i>
                <span className="text-white/70 text-[10px] font-bold uppercase tracking-widest">Fast Payout</span>
              </div>
            </div>

            {/* Login Button with Shimmer */}
            <button 
              onClick={startGoogleLogin}
              className="group relative w-full bg-white text-gray-900 py-5 rounded-[2rem] font-black text-lg shadow-[0_20px_40px_rgba(255,255,255,0.1)] flex items-center justify-center space-x-4 transition-all active:scale-95 hover:bg-indigo-50 overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent -translate-x-full group-hover:animate-[shimmer-sweep_1.5s_infinite]"></div>
              <img src="https://www.gstatic.com/images/branding/product/2x/googleg_48dp.png" alt="Google" className="w-7 h-7" />
              <span className="relative z-10">Continue with Google</span>
            </button>
            
            <p className="mt-8 text-[10px] text-gray-500 font-bold uppercase tracking-[0.2em] opacity-50">By joining you agree to our terms</p>
          </div>
        )}

        {step === 'nameEntry' && (
          <div className="w-full animate-fadeIn flex flex-col items-center">
            <div className="relative mb-10 p-2 bg-indigo-500/20 rounded-full">
              <img src={selectedAccount?.photo} alt="Avatar" className="w-28 h-28 rounded-full border-4 border-indigo-500 shadow-2xl object-cover" />
              <div className="absolute bottom-1 right-1 bg-green-500 w-10 h-10 rounded-full flex items-center justify-center border-4 border-[#050505] shadow-lg">
                <i className="fas fa-check text-white text-sm"></i>
              </div>
            </div>

            <div className="text-center mb-10">
              <p className="text-indigo-400 text-[10px] font-black uppercase tracking-[0.3em] mb-2">Authenticated</p>
              <h2 className="text-3xl font-black text-white italic mb-1 uppercase tracking-tight">Setup Profile</h2>
              <p className="text-gray-500 text-sm font-medium">Hello, {selectedAccount?.email.split('@')[0]}!</p>
            </div>

            <div className="w-full space-y-8">
              <div className="space-y-3">
                <label className="text-white/40 text-[10px] font-black uppercase tracking-[0.2em] ml-2">Display Name</label>
                <div className="relative group">
                  <input 
                    type="text" 
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    placeholder="Enter your name..."
                    className="w-full bg-white/5 border-2 border-white/10 p-6 rounded-[2rem] text-white font-bold outline-none focus:border-indigo-500 focus:bg-white/10 transition-all text-center text-2xl shadow-inner"
                    autoFocus
                  />
                  <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-0 h-1 bg-indigo-500 rounded-full transition-all duration-500 group-focus-within:w-1/2"></div>
                </div>
              </div>

              <button 
                onClick={handleFinalLogin}
                disabled={!userName.trim() || isSyncing}
                className={`w-full py-6 rounded-[2.2rem] font-black text-2xl shadow-2xl transition-all active:scale-95 flex items-center justify-center space-x-4 ${
                  userName.trim() && !isSyncing 
                  ? 'bg-indigo-600 text-white hover:bg-indigo-500 shadow-indigo-500/20' 
                  : 'bg-white/5 text-gray-600 cursor-not-allowed border border-white/5'
                }`}
              >
                {isSyncing ? (
                  <>
                    <i className="fas fa-spinner animate-spin"></i>
                    <span className="uppercase tracking-widest text-lg">Encrypting...</span>
                  </>
                ) : (
                  <>
                    <span>LET'S START</span>
                    <i className="fas fa-chevron-right text-sm opacity-50"></i>
                  </>
                )}
              </button>
              
              <button 
                onClick={() => setStep('picker')}
                className="w-full text-gray-500 text-[10px] font-black uppercase tracking-[0.3em] py-2 hover:text-white transition-colors"
              >
                Use another account
              </button>
            </div>
          </div>
        )}
      </div>

      {/* SYSTEM-STYLE GOOGLE ACCOUNT PICKER */}
      {step === 'picker' && (
        <div className="fixed inset-0 z-[1000] bg-black/95 flex flex-col items-center justify-center p-5 animate-fadeIn backdrop-blur-2xl">
          <div className="bg-[#1a1b1e] w-full max-w-[360px] rounded-[2.5rem] shadow-2xl overflow-hidden animate-scaleUp border border-white/10 p-1">
            <div className="p-8 flex flex-col items-center">
              <div className="w-16 h-16 rounded-3xl bg-[#2d2e32] flex items-center justify-center mb-6 shadow-xl border border-white/5">
                <i className="fas fa-user-shield text-[#8ab4f8] text-3xl"></i>
              </div>

              <h3 className="text-2xl font-bold text-[#e8eaed] mb-1">Select account</h3>
              <p className="text-[#9aa0a6] text-sm mb-10 text-center">Your progress will be linked to this account for Diamond Elite.</p>

              <div className="w-full space-y-3">
                <div 
                  onClick={() => handleAccountSelect('siam.pro.ff@gmail.com', 'https://i.pravatar.cc/150?u=siam')}
                  className="flex items-center p-5 bg-white/[0.03] hover:bg-white/[0.08] rounded-3xl cursor-pointer transition-all border border-white/5 group"
                >
                  <div className="relative">
                    <img src="https://i.pravatar.cc/150?u=siam" className="w-12 h-12 rounded-full mr-4 object-cover border-2 border-indigo-500/50" alt="Siam" />
                    <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-[#1a1b1e]"></div>
                  </div>
                  <div className="flex-1 overflow-hidden">
                    <p className="text-[#e8eaed] font-bold truncate group-hover:text-white transition-colors">Siam Ahmed</p>
                    <p className="text-[#9aa0a6] text-xs truncate">siam.pro.ff@gmail.com</p>
                  </div>
                  <i className="fas fa-chevron-right text-white/10 group-hover:text-indigo-400 transition-colors"></i>
                </div>

                <div 
                  onClick={() => handleAccountSelect('rafi.official@gmail.com', 'https://i.pravatar.cc/150?u=rafi')}
                  className="flex items-center p-5 bg-white/[0.03] hover:bg-white/[0.08] rounded-3xl cursor-pointer transition-all border border-white/5 group"
                >
                  <div className="relative">
                    <img src="https://i.pravatar.cc/150?u=rafi" className="w-12 h-12 rounded-full mr-4 object-cover border-2 border-indigo-500/50" alt="Rafi" />
                    <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-[#1a1b1e]"></div>
                  </div>
                  <div className="flex-1 overflow-hidden">
                    <p className="text-[#e8eaed] font-bold truncate group-hover:text-white transition-colors">Rafi Official</p>
                    <p className="text-[#9aa0a6] text-xs truncate">rafi.official@gmail.com</p>
                  </div>
                  <i className="fas fa-chevron-right text-white/10 group-hover:text-indigo-400 transition-colors"></i>
                </div>

                <div className="h-[1px] bg-white/5 my-4 mx-8"></div>

                <button className="w-full p-5 flex items-center text-[#e8eaed] hover:bg-white/5 rounded-3xl transition-colors text-left group">
                  <div className="w-12 h-12 rounded-full bg-[#2d2e32] flex items-center justify-center mr-4 border border-white/5 group-hover:bg-indigo-600 transition-colors">
                    <i className="fas fa-plus text-xs"></i>
                  </div>
                  <span className="text-sm font-bold tracking-tight">Add another account</span>
                </button>
              </div>

              <div className="mt-10 p-4 bg-indigo-500/5 rounded-2xl border border-indigo-500/10">
                <p className="text-[10px] text-[#9aa0a6] text-center leading-relaxed font-medium">
                  We value your privacy. Your data is encrypted and never shared with third parties without consent.
                </p>
              </div>
            </div>
            
            <div className="flex justify-center pb-5">
              <div className="w-20 h-1.5 bg-white/10 rounded-full"></div>
            </div>
          </div>
          
          <button 
            onClick={() => setStep('initial')}
            className="mt-10 text-gray-500 font-black uppercase tracking-[0.4em] text-[11px] hover:text-white transition-all bg-white/5 px-8 py-3 rounded-full border border-white/10"
          >
            DISMISS
          </button>
        </div>
      )}

      {/* Persistence message for the user */}
      <div className="absolute bottom-10 left-0 w-full text-center px-8 pointer-events-none">
        <div className="inline-flex items-center space-x-2 bg-indigo-900/10 backdrop-blur-md px-4 py-2 rounded-full border border-indigo-500/10">
          <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-pulse"></div>
          <p className="text-[8px] text-indigo-400 uppercase font-black tracking-[0.3em]">Cloud Persistence Verified (UID-88219)</p>
        </div>
      </div>
    </div>
  );
};

export default Auth;
