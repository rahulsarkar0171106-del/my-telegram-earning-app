
import React, { useState } from 'react';
import { UserState } from '../types';

interface ProfileProps {
  userState: UserState;
  setUserState: React.Dispatch<React.SetStateAction<UserState>>;
  onLogout: () => void;
}

const Profile: React.FC<ProfileProps> = ({ userState, setUserState, onLogout }) => {
  const { user, diamonds, highScores, lastSync } = userState;
  const [isEditingName, setIsEditingName] = useState(false);
  const [tempName, setTempName] = useState(user?.name || '');
  const [isSaving, setIsSaving] = useState(false);
  
  if (!user) return null;

  const currentLevel = Math.floor(diamonds / 500) + 1;
  const progressToNext = ((diamonds % 500) / 500) * 100;

  const handleSaveName = () => {
    if (!tempName.trim()) return;
    
    setIsSaving(true);
    // Simulate a brief delay for a better UX feel and cloud sync visualization
    setTimeout(() => {
        setUserState(prev => ({
            ...prev,
            user: {
                ...prev.user!,
                name: tempName.trim()
            },
            lastSync: new Date().toISOString()
        }));
        setIsSaving(false);
        setIsEditingName(false);
    }, 400);
  };

  const handleCancelEdit = () => {
    setTempName(user.name);
    setIsEditingName(false);
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-8">
      {/* Profile Header */}
      <div className="bg-white p-8 rounded-[3rem] shadow-sm border border-gray-100 flex flex-col items-center text-center relative overflow-hidden">
        <div className="absolute top-0 right-0 p-6 opacity-5">
            <i className="fas fa-gem text-9xl -rotate-12 text-indigo-900"></i>
        </div>
        
        <div className="relative mb-4">
            <img 
                src={user.photo} 
                alt={user.name} 
                className="w-28 h-28 rounded-full border-4 border-indigo-100 shadow-xl object-cover"
            />
            <div className="absolute bottom-1 right-1 bg-green-500 w-6 h-6 rounded-full border-4 border-white shadow-sm flex items-center justify-center">
              <i className="fas fa-check text-[8px] text-white"></i>
            </div>
        </div>
        
        {isEditingName ? (
            <div className="w-full max-w-[240px] space-y-3 mb-2 animate-scaleUp">
                <div className="relative">
                  <input 
                      type="text" 
                      value={tempName}
                      onChange={(e) => setTempName(e.target.value)}
                      className="w-full p-3 bg-gray-50 border-2 border-indigo-400 rounded-2xl text-center font-bold text-gray-800 outline-none shadow-inner focus:bg-white transition-all"
                      autoFocus
                      maxLength={20}
                      placeholder="Enter new name"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                    <button 
                        onClick={handleSaveName}
                        disabled={isSaving || !tempName.trim()}
                        className="bg-indigo-600 text-white py-2.5 rounded-xl text-xs font-black shadow-lg active:scale-95 transition-all disabled:opacity-50"
                    >
                        {isSaving ? <i className="fas fa-spinner animate-spin"></i> : 'SAVE'}
                    </button>
                    <button 
                        onClick={handleCancelEdit}
                        disabled={isSaving}
                        className="bg-gray-100 text-gray-500 py-2.5 rounded-xl text-xs font-black active:scale-95 transition-all border border-gray-200"
                    >
                        CANCEL
                    </button>
                </div>
            </div>
        ) : (
            <div className="flex flex-col items-center space-y-2">
                <h2 className="text-2xl font-black text-gray-800 tracking-tight">{user.name}</h2>
                <button 
                  onClick={() => setIsEditingName(true)}
                  className="inline-flex items-center space-x-2 bg-indigo-50 text-indigo-600 px-4 py-1.5 rounded-full text-[10px] font-black border border-indigo-100 hover:bg-indigo-100 transition-colors active:scale-95"
                >
                  <i className="fas fa-pencil-alt text-[9px]"></i>
                  <span>EDIT NAME</span>
                </button>
            </div>
        )}
        
        <p className="text-gray-400 font-bold text-[10px] uppercase tracking-[0.2em] mt-2">{user.email}</p>
        
        <div className="mt-4 flex space-x-2">
            <span className="bg-indigo-50 text-indigo-600 px-4 py-1.5 rounded-full text-xs font-black border border-indigo-100 flex items-center">
                <i className={`fab fa-google mr-2 text-indigo-400`}></i>
                SECURED ACCESS
            </span>
        </div>
      </div>

      {/* Level Card */}
      <div className="bg-white p-6 rounded-[2rem] shadow-sm border border-gray-100">
        <div className="flex justify-between items-end mb-3">
            <div>
                <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Player Rank</p>
                <p className="text-xl font-black text-gray-800 italic">Level {currentLevel}</p>
            </div>
            <p className="text-xs font-bold text-gray-400">{Math.floor(progressToNext)}% to Level {currentLevel + 1}</p>
        </div>
        <div className="w-full h-4 bg-gray-100 rounded-full overflow-hidden p-1 shadow-inner">
            <div 
                className="h-full diamond-gradient rounded-full transition-all duration-1000"
                style={{ width: `${progressToNext}%` }}
            ></div>
        </div>
      </div>

      {/* Statistics Grid */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white p-5 rounded-[2rem] shadow-sm border border-gray-100 text-center">
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Total Points</p>
            <div className="flex items-center justify-center space-x-2">
                <i className="fas fa-gem text-indigo-600"></i>
                <p className="text-2xl font-black text-gray-800 tracking-tighter">{diamonds.toLocaleString()}</p>
            </div>
        </div>
        <div className="bg-white p-5 rounded-[2rem] shadow-sm border border-gray-100 text-center">
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Best Tap</p>
            <div className="flex items-center justify-center space-x-2">
                <i className="fas fa-bolt text-orange-500"></i>
                <p className="text-2xl font-black text-gray-800 tracking-tighter">{highScores.tap}</p>
            </div>
        </div>
      </div>

      {/* Action Menu */}
      <div className="bg-white rounded-[2rem] shadow-sm border border-gray-100 overflow-hidden divide-y divide-gray-50">
         <button className="w-full p-5 flex items-center justify-between hover:bg-gray-50 transition-colors">
            <div className="flex items-center space-x-4">
                <div className="bg-blue-50 p-2.5 rounded-xl text-blue-500">
                    <i className="fas fa-sync"></i>
                </div>
                <div>
                   <p className="font-bold text-gray-700 text-left">Force Cloud Sync</p>
                   <p className="text-[9px] text-gray-400 italic">Last sync: {new Date(lastSync).toLocaleTimeString()}</p>
                </div>
            </div>
            <i className="fas fa-chevron-right text-gray-300 text-xs"></i>
         </button>
         <button className="w-full p-5 flex items-center justify-between hover:bg-gray-50 transition-colors text-left">
            <div className="flex items-center space-x-4">
                <div className="bg-green-50 p-2.5 rounded-xl text-green-500">
                    <i className="fas fa-history"></i>
                </div>
                <p className="font-bold text-gray-700">Withdrawal History</p>
            </div>
            <i className="fas fa-chevron-right text-gray-300 text-xs"></i>
         </button>
         <button 
            onClick={onLogout}
            className="w-full p-5 flex items-center justify-between hover:bg-red-50 transition-colors group"
         >
            <div className="flex items-center space-x-4 text-red-500">
                <div className="bg-red-50 p-2.5 rounded-xl group-hover:bg-red-500 group-hover:text-white transition-colors">
                    <i className="fas fa-power-off"></i>
                </div>
                <p className="font-bold">Logout Session</p>
            </div>
         </button>
      </div>

      <div className="text-center">
          <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Diamond elite Cloud Core v4.1.0</p>
      </div>
    </div>
  );
};

export default Profile;
