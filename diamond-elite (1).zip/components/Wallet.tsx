
import React, { useState } from 'react';
import { UserState } from '../types';
import InterstitialAd from './InterstitialAd';

interface WalletProps {
  userState: UserState;
  setUserState: React.Dispatch<React.SetStateAction<UserState>>;
}

const REDEEM_OPTIONS = [
  { id: 1, provider: 'Free Fire', icon: '💎', label: '100 Diamonds', cost: 10000, amount: 100 },
  { id: 2, provider: 'Free Fire', icon: '📅', label: 'Weekly Membership', cost: 20000, amount: 450 },
  { id: 3, provider: 'Free Fire', icon: '💎', label: '310 Diamonds', cost: 30000, amount: 310 },
  { id: 4, provider: 'Free Fire', icon: '💎', label: '520 Diamonds', cost: 50000, amount: 520 },
  { id: 5, provider: 'Free Fire', icon: '🏆', label: 'Monthly Membership', cost: 85000, amount: 2600 },
];

const Wallet: React.FC<WalletProps> = ({ userState, setUserState }) => {
  const [selectedRedeem, setSelectedRedeem] = useState<typeof REDEEM_OPTIONS[0] | null>(null);
  const [gameId, setGameId] = useState('');
  const [redeemSuccess, setRedeemSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [adOpen, setAdOpen] = useState(false);

  const handleRedeemClick = () => {
    setErrorMsg(null);
    if (!selectedRedeem) return;

    if (userState.diamonds < selectedRedeem.cost) {
      setErrorMsg("আপনার পর্যাপ্ত ডায়মন্ড হয় নাই পরে আবার চেষ্টা করো");
      return;
    }

    if (!gameId.trim()) {
      setErrorMsg("দয়া করে আপনার ফ্রি ফায়ার প্লেয়ার আইডি দিন");
      return;
    }

    setAdOpen(true);
  };

  const processRedeem = () => {
    setAdOpen(false);
    if (!selectedRedeem || !userState.user) return;

    // Deduct diamonds from state
    setUserState(prev => ({
      ...prev,
      diamonds: prev.diamonds - selectedRedeem.cost
    }));

    // Construct the mailto URL with the specified message format
    const recipient = "rahulsarkar19773@gmail.com"; 
    const subject = encodeURIComponent(`Withdrawal Request: ${selectedRedeem.label}`);
    const body = encodeURIComponent(
      `hi my name is ${userState.user.name}. I topup ${selectedRedeem.label} dimond. My uid ${gameId}. Give me ${selectedRedeem.amount} dimond`
    );

    const mailtoLink = `mailto:${recipient}?subject=${subject}&body=${body}`;

    // Open the email client
    window.location.href = mailtoLink;

    setRedeemSuccess(true);
    setSelectedRedeem(null);
    setGameId('');
    
    setTimeout(() => {
        setRedeemSuccess(false);
    }, 5000);
  };

  const closeModals = () => {
    setSelectedRedeem(null);
    setErrorMsg(null);
    setGameId('');
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-6">
      <div className="text-center">
        <h2 className="text-2xl font-black text-gray-800">Withdrawal</h2>
        <p className="text-gray-500 text-sm">Convert points into Free Fire rewards</p>
      </div>

      {/* Balance Summary */}
      <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 flex justify-between items-center">
        <div>
            <p className="text-sm text-gray-400 font-bold uppercase tracking-widest">Available Balance</p>
            <div className="flex items-baseline space-x-1">
                <p className="text-2xl font-black text-indigo-600">{userState.diamonds.toLocaleString()}</p>
                <span className="text-xs font-bold text-gray-400 uppercase">Points</span>
            </div>
        </div>
        <div className="bg-indigo-100 p-3 rounded-2xl text-indigo-600">
            <i className="fas fa-gem text-2xl"></i>
        </div>
      </div>

      {redeemSuccess && (
        <div className="bg-green-100 text-green-800 p-6 rounded-3xl border border-green-200 text-center animate-bounce shadow-sm">
            <i className="fas fa-check-circle text-3xl mb-2 text-green-500"></i>
            <h4 className="font-bold">Withdrawal Sent to Email!</h4>
            <p className="text-xs mt-1">Please send the pre-filled email to complete your request.</p>
        </div>
      )}

      {/* Redeem List */}
      <div className="space-y-3">
        <h3 className="font-bold text-gray-800 px-1 flex items-center">
          <i className="fas fa-list-ul mr-2 text-indigo-400"></i>
          Redeem Options
        </h3>
        {REDEEM_OPTIONS.map((opt) => (
          <button
            key={opt.id}
            onClick={() => {
              setSelectedRedeem(opt);
              setErrorMsg(null);
            }}
            className={`w-full p-4 rounded-2xl border transition-all flex items-center justify-between text-left ${
              selectedRedeem?.id === opt.id 
                ? 'border-indigo-500 bg-indigo-50 shadow-sm ring-1 ring-indigo-200' 
                : 'border-gray-100 bg-white hover:bg-gray-50'
            }`}
          >
            <div className="flex items-center space-x-3">
              <div className="text-2xl w-10 h-10 flex items-center justify-center bg-gray-100 rounded-xl group-hover:scale-110 transition-transform">
                {opt.icon}
              </div>
              <div>
                <p className="font-bold text-gray-800 leading-tight">{opt.provider}</p>
                <p className="text-[10px] text-gray-500 font-medium uppercase tracking-tighter">{opt.label}</p>
              </div>
            </div>
            <div className="text-right">
              <p className={`font-black ${userState.diamonds >= opt.cost ? 'text-indigo-600' : 'text-red-400'}`}>
                {opt.cost.toLocaleString()}
              </p>
              <p className="text-[8px] text-gray-400 uppercase font-black tracking-widest">Points Needed</p>
            </div>
          </button>
        ))}
      </div>

      {/* Redeem Form Modal */}
      {selectedRedeem && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-6 bg-black/60 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white w-full max-w-sm rounded-3xl p-6 space-y-4 animate-scaleUp shadow-2xl relative">
            <div className="flex justify-between items-start">
              <div>
                <h4 className="text-xl font-black text-gray-800 italic tracking-tight uppercase">Confirmation</h4>
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Withdrawal System</p>
              </div>
              <button onClick={closeModals} className="text-gray-300 hover:text-gray-500 transition-colors p-1">
                <i className="fas fa-times-circle text-2xl"></i>
              </button>
            </div>

            {/* Error Notification */}
            {errorMsg && (
              <div className="bg-red-50 text-red-600 p-4 rounded-2xl border border-red-100 flex items-center space-x-3 animate-winningPop">
                <i className="fas fa-exclamation-triangle text-xl shrink-0"></i>
                <p className="text-sm font-bold leading-tight">{errorMsg}</p>
              </div>
            )}
            
            <div className="p-5 bg-indigo-50 rounded-2xl border-2 border-indigo-100 flex justify-between items-center">
              <div>
                <p className="text-[10px] text-indigo-400 font-black uppercase tracking-widest mb-1">Item Selected</p>
                <p className="font-black text-lg text-gray-800 leading-tight">{selectedRedeem.label}</p>
              </div>
              <div className="text-right">
                <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest mb-1">Cost</p>
                <p className="font-black text-indigo-600 text-lg">{selectedRedeem.cost.toLocaleString()}</p>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-black text-gray-400 uppercase ml-1 tracking-widest">Free Fire Player ID</label>
              <div className="relative">
                <i className="fas fa-user-tag absolute left-4 top-1/2 -translate-y-1/2 text-gray-300"></i>
                <input 
                  type="text" 
                  value={gameId}
                  onChange={(e) => setGameId(e.target.value)}
                  placeholder="Paste your UID here..."
                  className="w-full p-4 pl-12 bg-gray-50 rounded-2xl border-2 border-gray-100 focus:border-indigo-500 focus:bg-white outline-none transition-all font-bold text-gray-700"
                />
              </div>
            </div>

            <button 
              onClick={handleRedeemClick}
              className="w-full py-5 diamond-gradient text-white rounded-2xl font-black text-xl shadow-lg active:scale-95 transition-transform group"
            >
              <span className="group-active:scale-95 inline-block">REDEEM NOW</span>
              <p className="text-[10px] opacity-80 font-bold uppercase tracking-widest mt-0.5">Will show 15s Ad</p>
            </button>
          </div>
        </div>
      )}

      <InterstitialAd isOpen={adOpen} onClose={processRedeem} title="PROCESSING WITHDRAWAL" />
    </div>
  );
};

export default Wallet;
