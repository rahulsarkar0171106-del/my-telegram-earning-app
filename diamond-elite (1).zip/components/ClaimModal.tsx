
import React, { useState, useEffect, useRef } from 'react';

interface ClaimModalProps {
  isOpen: boolean;
  amount: number;
  onClaim: () => void;
  title?: string;
}

const ClaimModal: React.FC<ClaimModalProps> = ({ isOpen, amount, onClaim, title = "CONGRATULATIONS!" }) => {
  const [view, setView] = useState<'reward' | 'ad'>('reward');
  const [timeLeft, setTimeLeft] = useState(0);
  const [canClose, setCanClose] = useState(false);
  const [durations, setDurations] = useState({ claim: 15, skip: 5 });
  const timerRef = useRef<number | null>(null);

  const AD_URL = 'https://www.effectivegatecpm.com/q7m07sggj?key=0febc73b4772d20c71652935f8240078';
  
  const isLoss = amount === 0;
  const displayTitle = isLoss ? "BETTER LUCK NEXT TIME!" : title;
  const displayIcon = isLoss ? "fa-heart-broken" : "fa-gem";

  useEffect(() => {
    if (isOpen) {
      setView('reward');
      setTimeLeft(0);
      setCanClose(false);
      
      // Randomize durations between 5 and 15 seconds
      // Claim duration: 10 to 15 seconds
      const claimDur = Math.floor(Math.random() * (15 - 10 + 1)) + 10;
      // Skip duration: 5 to (claimDur - 1) seconds
      const skipDur = Math.floor(Math.random() * (claimDur - 1 - 5 + 1)) + 5;
      
      setDurations({ claim: claimDur, skip: skipDur });

      if (timerRef.current) clearInterval(timerRef.current);
    }
  }, [isOpen]);

  const startAd = (duration: number) => {
    setView('ad');
    setTimeLeft(duration);
    setCanClose(false);

    timerRef.current = window.setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          if (timerRef.current) clearInterval(timerRef.current);
          setCanClose(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleClaimClick = () => {
    startAd(durations.claim);
  };

  const handleCancelClick = () => {
    startAd(durations.skip);
  };

  const handleFinish = () => {
    onClaim();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/95 backdrop-blur-xl animate-fadeIn">
      {view === 'reward' ? (
        <div className="bg-white w-full max-w-sm rounded-[2.5rem] p-8 text-center shadow-2xl border-4 border-indigo-500 animate-scaleUp relative overflow-hidden">
          {/* Decorative background elements */}
          <div className="absolute -top-10 -left-10 w-32 h-32 bg-indigo-100 rounded-full opacity-50"></div>
          <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-purple-100 rounded-full opacity-50"></div>
          
          <div className="relative z-10">
            <div className={`w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg animate-bounce ${isLoss ? 'bg-gray-200' : 'diamond-gradient'}`}>
              <i className={`fas ${displayIcon} text-white text-4xl`}></i>
            </div>
            
            <h2 className="text-2xl font-black text-gray-800 mb-2 tracking-tight italic">{displayTitle}</h2>
            <p className="text-gray-500 font-medium mb-6 uppercase tracking-widest text-sm">
              {isLoss ? "You didn't win this time" : "Great Job! You won"}
            </p>
            
            {!isLoss && (
              <div className="flex items-center justify-center space-x-3 mb-8">
                <span className="text-6xl font-black text-indigo-600 drop-shadow-sm">{amount}</span>
                <div className="text-left">
                  <p className="text-xl font-bold text-gray-800 leading-none">DIAMONDS</p>
                  <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-tighter">Ready to add</p>
                </div>
              </div>
            )}

            {isLoss && (
              <div className="mb-8 p-4 bg-gray-50 rounded-2xl italic text-gray-400 text-sm border-2 border-dashed border-gray-100">
                "Keep spinning! Big prizes are waiting for you."
              </div>
            )}
            
            <div className="space-y-3">
              <button 
                onClick={handleClaimClick}
                className="w-full py-5 diamond-gradient text-white rounded-2xl font-black text-xl shadow-[0_10px_20px_rgba(99,102,241,0.4)] transition-all active:scale-95 hover:brightness-110 flex items-center justify-center space-x-3"
              >
                <span>{isLoss ? `CONTINUE (${durations.claim}s Ad)` : `CLAIM (${durations.claim}s Ad)`}</span>
                <i className="fas fa-arrow-right text-sm"></i>
              </button>
              
              <button 
                onClick={handleCancelClick}
                className="w-full py-3 bg-gray-100 text-gray-400 rounded-2xl font-bold text-sm hover:bg-gray-200 transition-colors"
              >
                SKIP ({durations.skip}s Ad)
              </button>
            </div>
            
            <p className="mt-4 text-[10px] text-gray-400 font-medium uppercase tracking-widest">Ad will show inside the app</p>
          </div>
        </div>
      ) : (
        <div className="w-full h-full flex flex-col animate-scaleUp">
          {/* Ad Header with Countdown */}
          <div className="bg-white/10 backdrop-blur-md p-4 flex justify-between items-center text-white border-b border-white/20">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center font-bold border-2 border-white">
                {timeLeft}
              </div>
              <div>
                <p className="text-xs font-bold uppercase tracking-widest">Sponsored Content</p>
                <p className="text-[10px] opacity-70">Completing in {timeLeft}s</p>
              </div>
            </div>
            
            {canClose && (
              <button 
                onClick={handleFinish}
                className="bg-green-500 text-white px-6 py-2 rounded-full font-black text-sm shadow-lg animate-pulse border-2 border-white"
              >
                {isLoss ? 'FINISH' : 'COLLECT NOW'}
              </button>
            )}
          </div>

          {/* Ad Content Container */}
          <div className="flex-1 bg-white relative overflow-hidden">
             <iframe 
               src={AD_URL} 
               className="w-full h-full border-none"
               title="Reward Ad"
             />
             
             {!canClose && (
               <div className="absolute inset-0 pointer-events-none border-4 border-indigo-500/30"></div>
             )}
          </div>

          {/* Bottom Banner */}
          <div className="bg-indigo-600 p-2 text-center">
             <p className="text-[10px] text-white font-bold uppercase tracking-[0.2em]">Wait for the timer to finish</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default ClaimModal;
