
import React, { useState, useEffect, useRef } from 'react';

interface InterstitialAdProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
}

const InterstitialAd: React.FC<InterstitialAdProps> = ({ isOpen, onClose, title = "LOADING CONTENT..." }) => {
  const [timeLeft, setTimeLeft] = useState(15);
  const [canClose, setCanClose] = useState(false);
  const timerRef = useRef<number | null>(null);

  const AD_URL = 'https://www.effectivegatecpm.com/q7m07sggj?key=0febc73b4772d20c71652935f8240078';

  useEffect(() => {
    if (isOpen) {
      setTimeLeft(15);
      setCanClose(false);
      timerRef.current = window.setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            if (timerRef.current) clearInterval(timerRef.current);
            setCanClose(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[200] flex flex-col bg-black animate-fadeIn">
      {/* Ad Header */}
      <div className="bg-white/10 backdrop-blur-md p-4 flex justify-between items-center text-white border-b border-white/20">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center font-bold border-2 border-white">
            {timeLeft}
          </div>
          <div>
            <p className="text-xs font-bold uppercase tracking-widest">{title}</p>
            <p className="text-[10px] opacity-70">Please wait {timeLeft}s to continue</p>
          </div>
        </div>
        
        {canClose && (
          <button 
            onClick={onClose}
            className="bg-green-500 text-white px-6 py-2 rounded-full font-black text-sm shadow-lg border-2 border-white animate-pulse"
          >
            CONTINUE
          </button>
        )}
      </div>

      {/* Ad Content */}
      <div className="flex-1 bg-white relative">
         <iframe 
           src={AD_URL} 
           className="w-full h-full border-none"
           title="Interstitial Ad"
         />
      </div>

      {/* Footer */}
      <div className="bg-indigo-600 p-2 text-center">
         <p className="text-[10px] text-white font-bold uppercase tracking-widest">Sponsored Content</p>
      </div>
    </div>
  );
};

export default InterstitialAd;
