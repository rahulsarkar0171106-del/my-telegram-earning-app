
import React from 'react';
import { AppTab } from '../types';

interface NavigationProps {
  activeTab: AppTab;
  setActiveTab: (tab: AppTab) => void;
}

const Navigation: React.FC<NavigationProps> = ({ activeTab, setActiveTab }) => {
  const tabs = [
    { id: AppTab.HOME, icon: 'fa-home', label: 'Home' },
    { id: AppTab.SPIN, icon: 'fa-sync-alt', label: 'Spin' },
    { id: AppTab.SCRATCH, icon: 'fa-eraser', label: 'Scratch' },
    { id: AppTab.GAMES, icon: 'fa-gamepad', label: 'Games' },
    { id: AppTab.WALLET, icon: 'fa-wallet', label: 'Wallet' },
    { id: AppTab.PROFILE, icon: 'fa-user-circle', label: 'Profile' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white/80 backdrop-blur-md border-t border-gray-100 flex justify-around items-center py-2 px-1 z-50 shadow-[0_-4px_15px_rgba(0,0,0,0.05)] rounded-t-[2rem]">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => setActiveTab(tab.id)}
          className={`flex flex-col items-center flex-1 transition-all duration-300 relative ${
            activeTab === tab.id ? 'text-indigo-600 scale-110' : 'text-gray-400 hover:text-gray-600'
          }`}
        >
          <div className={`p-2 rounded-2xl transition-all duration-300 ${activeTab === tab.id ? 'bg-indigo-50 shadow-inner' : ''}`}>
            <i className={`fas ${tab.icon} text-lg ${activeTab === tab.id ? 'animate-heartbeat' : ''}`}></i>
          </div>
          <span className={`text-[9px] mt-0.5 font-bold transition-all ${activeTab === tab.id ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-1'}`}>{tab.label}</span>
          {activeTab === tab.id && (
            <div className="absolute -bottom-1 h-1.5 w-1.5 bg-indigo-600 rounded-full animate-pulse shadow-[0_0_8px_rgba(79,70,229,0.5)]"></div>
          )}
        </button>
      ))}
    </nav>
  );
};

export default Navigation;
