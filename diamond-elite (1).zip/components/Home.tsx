
import React, { useState } from 'react';
import { AppTab, UserState } from '../types';
import InterstitialAd from './InterstitialAd';

interface HomeProps {
  setActiveTab: (tab: AppTab) => void;
  userState: UserState;
}

const Home: React.FC<HomeProps> = ({ setActiveTab, userState }) => {
  const [adOpen, setAdOpen] = useState(false);
  const [pendingTab, setPendingTab] = useState<AppTab | null>(null);

  const handleTabClick = (tab: AppTab) => {
    setPendingTab(tab);
    setAdOpen(true);
  };

  const handleAdClose = () => {
    setAdOpen(false);
    if (pendingTab) {
      setActiveTab(pendingTab);
    }
  };

  const firstName = userState.user?.name.split(' ')[0] || 'User';

  return (
    <div className="space-y-6 animate-fadeIn pb-4">
      {/* Banner */}
      <div className="diamond-gradient p-6 rounded-[2.5rem] text-white shadow-lg overflow-hidden relative animate-slideUp">
        <div className="relative z-10">
          <h2 className="text-2xl font-black tracking-tight">Hi, {firstName}! 👋</h2>
          <p className="opacity-90 text-sm mt-1 font-medium">Get ready to win big diamonds today.</p>
          <button 
            onClick={() => handleTabClick(AppTab.SPIN)}
            className="mt-5 bg-white text-indigo-600 px-8 py-2.5 rounded-2xl font-black text-sm shadow-sm active:scale-95 transition-all hover:shadow-md uppercase tracking-wider"
          >
            Start Spinning
          </button>
        </div>
        <i className="fas fa-gem absolute -right-6 -bottom-6 text-white/10 text-[12rem] animate-float"></i>
      </div>

      {/* Daily Stats */}
      <div className="grid grid-cols-3 gap-3 animate-slideUp stagger-1 opacity-0 fill-mode-forwards">
        <StatCard icon="fa-sync-alt" color="text-blue-600" bgColor="bg-blue-50" label="Spins" value={userState.spinsRemaining} />
        <StatCard icon="fa-eraser" color="text-purple-600" bgColor="bg-purple-50" label="Cards" value={userState.scratchCardsRemaining} />
        <StatCard icon="fa-gamepad" color="text-orange-600" bgColor="bg-orange-50" label="Games" value={userState.gamesRemaining} />
      </div>

      {/* Quick Menu */}
      <div className="animate-slideUp stagger-2 opacity-0 fill-mode-forwards">
        <div className="flex justify-between items-center mb-4 px-1">
          <h3 className="text-lg font-black text-gray-800 tracking-tight italic uppercase">Quick Features</h3>
          <span className="text-[10px] font-black text-indigo-400 bg-indigo-50 px-3 py-1 rounded-full border border-indigo-100 uppercase tracking-widest">Boost Rewards</span>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <MenuCard 
            icon="fa-sync-alt" 
            color="bg-blue-500" 
            title="Lucky Spin" 
            subtitle="Spin & Win Up to 40" 
            onClick={() => handleTabClick(AppTab.SPIN)}
          />
          <MenuCard 
            icon="fa-eraser" 
            color="bg-purple-500" 
            title="Scratch" 
            subtitle="Test Your Luck" 
            onClick={() => handleTabClick(AppTab.SCRATCH)}
          />
          <MenuCard 
            icon="fa-gamepad" 
            color="bg-orange-500" 
            title="Mini Games" 
            subtitle="Fast Reaction Task" 
            onClick={() => handleTabClick(AppTab.GAMES)}
          />
          <MenuCard 
            icon="fa-wallet" 
            color="bg-green-500" 
            title="Redeem" 
            subtitle="Get Free Fire Pts" 
            onClick={() => handleTabClick(AppTab.WALLET)}
          />
        </div>
      </div>

      {/* Footer Info */}
      <div className="bg-white p-6 rounded-[2rem] border border-dashed border-gray-200 text-center animate-slideUp stagger-3 opacity-0 fill-mode-forwards">
        <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.3em] mb-1">Status</p>
        <div className="flex items-center justify-center space-x-2">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          <span className="text-xs font-bold text-gray-700">Cloud Core Secure Connected</span>
        </div>
      </div>

      <InterstitialAd isOpen={adOpen} onClose={handleAdClose} title="STARTING FEATURE" />
    </div>
  );
};

const StatCard: React.FC<{ icon: string, color: string, bgColor: string, label: string, value: number }> = ({ icon, color, bgColor, label, value }) => (
  <div className="bg-white p-4 rounded-[1.8rem] shadow-sm border border-gray-100 flex flex-col items-center justify-center text-center transition-all hover:translate-y-[-2px] hover:shadow-md active:scale-95">
    <div className={`${bgColor} ${color} w-10 h-10 rounded-xl mb-2 flex items-center justify-center`}>
      <i className={`fas ${icon} text-sm`}></i>
    </div>
    <p className="text-[10px] text-gray-400 uppercase font-black tracking-widest leading-none mb-1">{label}</p>
    <p className="font-black text-gray-800 text-base leading-none">{value}</p>
  </div>
);

const MenuCard: React.FC<{ icon: string, color: string, title: string, subtitle: string, onClick: () => void }> = ({ icon, color, title, subtitle, onClick }) => (
  <button 
    onClick={onClick}
    className="bg-white p-5 rounded-[2.2rem] shadow-sm border border-gray-100 text-left active:scale-95 transition-all group hover:shadow-md relative overflow-hidden"
  >
    <div className="relative z-10">
      <div className={`${color} w-11 h-11 rounded-2xl flex items-center justify-center text-white mb-4 shadow-lg group-hover:rotate-12 transition-transform`}>
        <i className={`fas ${icon} text-lg`}></i>
      </div>
      <h4 className="font-black text-gray-800 leading-tight text-sm uppercase italic tracking-tighter">{title}</h4>
      <p className="text-[9px] text-gray-400 mt-1 uppercase font-bold tracking-wider">{subtitle}</p>
    </div>
    <div className="absolute -right-4 -bottom-4 bg-gray-50 rounded-full w-16 h-16 opacity-0 group-hover:opacity-100 transition-opacity"></div>
  </button>
);

export default Home;
