
import React, { useState, useEffect, useRef, useCallback } from 'react';
import ClaimModal from './ClaimModal';
import LeaderboardModal from './LeaderboardModal';
import { UserState } from '../types';

interface GamesProps {
  addDiamonds: (amount: number) => void;
  useGamePlay: () => boolean;
  userState: UserState;
  updateHighScore: (game: keyof UserState['highScores'], score: number) => void;
}

interface MemoryCard {
  id: number;
  icon: string;
  isFlipped: boolean;
  isMatched: boolean;
}

const MEMORY_ICONS = [
  'fa-gem', 'fa-bolt', 'fa-star', 'fa-heart', 'fa-fire', 'fa-ghost'
];

const Games: React.FC<GamesProps> = ({ addDiamonds, useGamePlay, userState, updateHighScore }) => {
  // Claim State
  const [showClaim, setShowClaim] = useState(false);
  const [pendingReward, setPendingReward] = useState(0);
  const [claimTitle, setClaimTitle] = useState("MISSION COMPLETE!");

  // Leaderboard State
  const [leaderboardConfig, setLeaderboardConfig] = useState<{ isOpen: boolean; type: 'tap' | 'memory' | 'math'; title: string } | null>(null);

  // Diamond Tap State
  const [tapGameActive, setTapGameActive] = useState(false);
  const [tapScore, setTapScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(15);
  const [targetPos, setTargetPos] = useState({ top: '50%', left: '50%' });
  const [isHit, setIsHit] = useState(false);
  const tapAreaRef = useRef<HTMLDivElement>(null);
  const timerRef = useRef<number | null>(null);

  // Memory Match State
  const [memoryGameActive, setMemoryGameActive] = useState(false);
  const [memoryCards, setMemoryCards] = useState<MemoryCard[]>([]);
  const [flippedIndices, setFlippedIndices] = useState<number[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [memoryStartTime, setMemoryStartTime] = useState(0);

  // Math Quiz State
  const [mathGameActive, setMathGameActive] = useState(false);
  const [mathQuestion, setMathQuestion] = useState({ a: 0, b: 0, op: '+', ans: 0 });
  const [mathInput, setMathInput] = useState('');
  const [mathRound, setMathRound] = useState(1);
  const [mathScore, setMathScore] = useState(0);

  const hasPlaysRemaining = userState.gamesRemaining > 0;

  // Diamond Tap Logic
  const startTapGame = () => {
    if (!hasPlaysRemaining) {
      alert("Daily game limit reached! Come back tomorrow.");
      return;
    }
    if (useGamePlay()) {
      setTapGameActive(true);
      setTapScore(0);
      setTimeLeft(15);
      moveTarget();
      
      timerRef.current = window.setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            endTapGame();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
  };

  const moveTarget = () => {
    if (!tapAreaRef.current) return;
    const padding = 60; // Increased padding to avoid edge-hugging
    const width = tapAreaRef.current.clientWidth - padding;
    const height = tapAreaRef.current.clientHeight - padding;
    const newTop = Math.floor(Math.random() * height) + padding / 2;
    const newLeft = Math.floor(Math.random() * width) + padding / 2;
    setTargetPos({ top: `${newTop}px`, left: `${newLeft}px` });
    setIsHit(false);
  };

  const handleTargetTap = (e: React.MouseEvent) => {
    if (isHit) return; // Prevent double taps during animation
    e.stopPropagation();
    setTapScore(prev => prev + 1);
    setIsHit(true);
    // Move after the animation duration (200ms)
    setTimeout(moveTarget, 200);
  };

  const endTapGame = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    const finalScore = tapScore; 
    setTapGameActive(false);
    updateHighScore('tap', finalScore);
    
    if (finalScore > 0) {
      setPendingReward(10);
      setClaimTitle("FAST TAPPER!");
      setShowClaim(true);
    } else {
      alert("Time's up! No diamonds tapped. Try again!");
    }
  };

  // Memory Match Logic (unchanged)
  const startMemoryGame = () => {
    if (!hasPlaysRemaining) {
      alert("Daily game limit reached! Come back tomorrow.");
      return;
    }
    if (useGamePlay()) {
      const pairedIcons = [...MEMORY_ICONS, ...MEMORY_ICONS];
      const shuffled = pairedIcons
        .sort(() => Math.random() - 0.5)
        .map((icon, index) => ({
          id: index,
          icon,
          isFlipped: false,
          isMatched: false,
        }));
      setMemoryCards(shuffled);
      setMemoryGameActive(true);
      setFlippedIndices([]);
      setIsProcessing(false);
      setMemoryStartTime(Date.now());
    }
  };

  const handleCardClick = (index: number) => {
    if (isProcessing || memoryCards[index].isFlipped || memoryCards[index].isMatched || flippedIndices.length === 2) return;

    const newIndices = [...flippedIndices, index];
    setFlippedIndices(newIndices);

    const newCards = [...memoryCards];
    newCards[index].isFlipped = true;
    setMemoryCards(newCards);

    if (newIndices.length === 2) {
      setIsProcessing(true);
      const [first, second] = newIndices;
      
      if (memoryCards[first].icon === memoryCards[second].icon) {
        setTimeout(() => {
          const matchedCards = [...newCards];
          matchedCards[first].isMatched = true;
          matchedCards[second].isMatched = true;
          setMemoryCards(matchedCards);
          setFlippedIndices([]);
          setIsProcessing(false);

          if (matchedCards.every(card => card.isMatched)) {
            const timeTaken = Math.floor((Date.now() - memoryStartTime) / 1000);
            updateHighScore('memory', timeTaken);
            setPendingReward(15);
            setClaimTitle("MEMORY GENIUS!");
            setShowClaim(true);
            setMemoryGameActive(false);
          }
        }, 600);
      } else {
        setTimeout(() => {
          const resetCards = [...newCards];
          resetCards[first].isFlipped = false;
          resetCards[second].isFlipped = false;
          setMemoryCards(resetCards);
          setFlippedIndices([]);
          setIsProcessing(false);
        }, 1000);
      }
    }
  };

  // Math Quiz Logic (unchanged)
  const generateMathQuestion = useCallback(() => {
    const a = Math.floor(Math.random() * 50) + 1;
    const b = Math.floor(Math.random() * 50) + 1;
    const op = Math.random() > 0.5 ? '+' : '-';
    const ans = op === '+' ? a + b : a - b;
    setMathQuestion({ a, b, op, ans });
    setMathInput('');
  }, []);

  const startMathGame = () => {
    if (!hasPlaysRemaining) {
      alert("Daily game limit reached! Come back tomorrow.");
      return;
    }
    if (useGamePlay()) {
      setMathGameActive(true);
      setMathRound(1);
      setMathScore(0);
      generateMathQuestion();
    }
  };

  const handleMathSubmit = () => {
    const userAns = parseInt(mathInput);
    if (isNaN(userAns)) return;

    const isCurrentCorrect = userAns === mathQuestion.ans;
    const currentScore = mathScore + (isCurrentCorrect ? 1 : 0);
    
    if (isCurrentCorrect) {
      setMathScore(currentScore);
    }

    if (mathRound < 5) {
      setMathRound(prev => prev + 1);
      generateMathQuestion();
    } else {
      const finalScore = currentScore;
      updateHighScore('math', finalScore);
      if (finalScore >= 3) {
        setPendingReward(6);
        setClaimTitle("MATH MASTER (6💎)");
      } else {
        setPendingReward(4);
        setClaimTitle("MATH PRACTICE (4💎)");
      }
      setShowClaim(true);
      setMathGameActive(false);
    }
  };

  const handleClaim = () => {
    addDiamonds(pendingReward);
    setShowClaim(false);
    setPendingReward(0);
  };

  const openLeaderboard = (type: 'tap' | 'memory' | 'math', title: string) => {
    setLeaderboardConfig({ isOpen: true, type, title });
  };

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      <div className="text-center">
        <h2 className="text-2xl font-black text-gray-800 tracking-tight">Mini Games</h2>
        <p className="text-gray-500 text-sm">Complete tasks to earn quick diamonds</p>
        <div className="mt-2 inline-block px-3 py-1 bg-indigo-50 border border-indigo-100 rounded-full">
            <p className="text-xs font-bold text-indigo-600">Daily Plays Left: {userState.gamesRemaining}</p>
        </div>
      </div>

      {/* Game 1: Diamond Tap Reaction Game */}
      <div className={`bg-white p-6 rounded-[2rem] shadow-sm border border-gray-100 overflow-hidden relative ${!hasPlaysRemaining && !tapGameActive ? 'opacity-75 grayscale-[0.5]' : ''}`}>
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center space-x-3">
              <div className="bg-indigo-100 p-3 rounded-2xl text-indigo-600">
                  <i className="fas fa-bolt text-xl"></i>
              </div>
              <div>
                  <h3 className="font-bold text-gray-800">Diamond Tap</h3>
                  <p className="text-xs text-gray-400">Personal Best: {userState.highScores.tap} taps</p>
              </div>
          </div>
          <button 
            onClick={() => openLeaderboard('tap', 'Diamond Tap')}
            className="p-3 bg-gray-50 text-yellow-600 rounded-2xl hover:bg-yellow-50 transition-colors border border-gray-100 shadow-sm"
          >
            <i className="fas fa-trophy"></i>
          </button>
        </div>

        {!tapGameActive ? (
          <div className="space-y-3">
             <p className="text-xs text-center text-gray-500">You have 15 seconds to tap moving diamonds. Win 10 diamonds for completing the game!</p>
             <button 
                onClick={startTapGame}
                disabled={!hasPlaysRemaining}
                className={`w-full py-4 rounded-2xl font-bold shadow-md active:scale-95 transition-transform ${
                    hasPlaysRemaining ? 'bg-indigo-500 text-white' : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                }`}
              >
                {hasPlaysRemaining ? 'START CHALLENGE' : 'LIMIT REACHED'}
              </button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex justify-between items-center text-sm font-bold text-gray-700 mb-2">
                <span className="bg-red-50 text-red-600 px-3 py-1 rounded-full border border-red-100">Time: {timeLeft}s</span>
                <span className="bg-green-50 text-green-600 px-3 py-1 rounded-full border border-green-100">Score: {tapScore}</span>
            </div>
            <div 
                ref={tapAreaRef}
                className="relative w-full h-48 bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200 overflow-hidden cursor-crosshair"
            >
                <button
                    key={`${targetPos.top}-${targetPos.left}`}
                    onClick={handleTargetTap}
                    className={`absolute w-14 h-14 flex items-center justify-center diamond-gradient rounded-2xl shadow-xl transition-all animate-targetSpawn ${isHit ? 'animate-targetTap' : ''}`}
                    style={{ 
                        top: targetPos.top, 
                        left: targetPos.left,
                        transform: 'translate(-50%, -50%)'
                    }}
                >
                    <i className="fas fa-gem text-white text-2xl"></i>
                </button>
            </div>
          </div>
        )}
      </div>

      {/* Other games omitted for brevity as they are unchanged */}
      <div className={`bg-white p-6 rounded-[2rem] shadow-sm border border-gray-100 overflow-hidden relative ${!hasPlaysRemaining && !memoryGameActive ? 'opacity-75 grayscale-[0.5]' : ''}`}>
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center space-x-3">
              <div className="bg-purple-100 p-3 rounded-2xl text-purple-600">
                  <i className="fas fa-brain text-xl"></i>
              </div>
              <div>
                  <h3 className="font-bold text-gray-800">Memory Match</h3>
                  <p className="text-xs text-gray-400">Fastest Time: {userState.highScores.memory === 999 ? 'N/A' : `${userState.highScores.memory}s`}</p>
              </div>
          </div>
          <button 
            onClick={() => openLeaderboard('memory', 'Memory Match')}
            className="p-3 bg-gray-50 text-yellow-600 rounded-2xl hover:bg-yellow-50 transition-colors border border-gray-100 shadow-sm"
          >
            <i className="fas fa-trophy"></i>
          </button>
        </div>
        {!memoryGameActive ? (
          <button onClick={startMemoryGame} disabled={!hasPlaysRemaining} className={`w-full py-4 rounded-2xl font-bold shadow-md active:scale-95 transition-transform ${hasPlaysRemaining ? 'bg-purple-600 text-white' : 'bg-gray-200 text-gray-400 cursor-not-allowed'}`}>
            {hasPlaysRemaining ? 'PLAY MEMORY MATCH' : 'LIMIT REACHED'}
          </button>
        ) : (
          <div className="grid grid-cols-4 gap-2">
            {memoryCards.map((card, index) => (
              <button key={card.id} onClick={() => handleCardClick(index)} className={`aspect-square rounded-xl flex items-center justify-center text-xl transition-all duration-300 transform ${card.isFlipped || card.isMatched ? 'bg-purple-100 text-purple-600 rotate-0' : 'bg-gray-100 text-gray-100 rotate-180'}`}>
                <i className={`fas ${card.icon} ${card.isFlipped || card.isMatched ? 'opacity-100' : 'opacity-0'}`}></i>
              </button>
            ))}
          </div>
        )}
      </div>

      <div className={`bg-white p-6 rounded-[2rem] shadow-sm border border-gray-100 overflow-hidden relative ${!hasPlaysRemaining && !mathGameActive ? 'opacity-75 grayscale-[0.5]' : ''}`}>
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center space-x-3">
              <div className="bg-green-100 p-3 rounded-2xl text-green-600">
                  <i className="fas fa-calculator text-xl"></i>
              </div>
              <div>
                  <h3 className="font-bold text-gray-800">Math Quiz</h3>
                  <p className="text-xs text-gray-400">Best Score: {userState.highScores.math}/5 pts</p>
              </div>
          </div>
          <button onClick={() => openLeaderboard('math', 'Math Quiz')} className="p-3 bg-gray-50 text-yellow-600 rounded-2xl hover:bg-yellow-50 transition-colors border border-gray-100 shadow-sm">
            <i className="fas fa-trophy"></i>
          </button>
        </div>
        {!mathGameActive ? (
          <button onClick={startMathGame} disabled={!hasPlaysRemaining} className={`w-full py-4 rounded-2xl font-bold shadow-md active:scale-95 transition-transform ${hasPlaysRemaining ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-400 cursor-not-allowed'}`}>
            {hasPlaysRemaining ? 'START QUIZ' : 'LIMIT REACHED'}
          </button>
        ) : (
          <div className="space-y-5">
            <div className="flex justify-between items-center"><span className="text-xs font-black text-gray-400 uppercase tracking-widest">Question {mathRound}/5</span></div>
            <div className="p-8 bg-gray-50 rounded-3xl text-center border-2 border-dashed border-gray-200"><p className="text-4xl font-black text-gray-800 tracking-tighter">{mathQuestion.a} {mathQuestion.op} {mathQuestion.b} = ?</p></div>
            <input type="number" value={mathInput} onChange={(e) => setMathInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleMathSubmit()} placeholder="Your answer..." className="w-full p-4 bg-white border-2 border-gray-200 rounded-2xl focus:border-green-500 outline-none text-center font-bold text-xl" autoFocus />
            <button onClick={handleMathSubmit} className="w-full py-4 bg-green-600 text-white rounded-2xl font-bold shadow-md active:scale-95 transition-transform">{mathRound === 5 ? 'FINISH' : 'NEXT'}</button>
          </div>
        )}
      </div>

      <ClaimModal isOpen={showClaim} amount={pendingReward} onClaim={handleClaim} title={claimTitle} />
      {leaderboardConfig && (
        <LeaderboardModal isOpen={leaderboardConfig.isOpen} onClose={() => setLeaderboardConfig(null)} gameTitle={leaderboardConfig.title} gameType={leaderboardConfig.type} userScore={userState.highScores[leaderboardConfig.type]} />
      )}
    </div>
  );
};

export default Games;
