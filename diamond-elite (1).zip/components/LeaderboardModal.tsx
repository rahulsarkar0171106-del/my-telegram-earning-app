
import React, { useMemo } from 'react';
import { LeaderboardEntry } from '../types';

interface LeaderboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  gameTitle: string;
  userScore: number;
  gameType: 'tap' | 'memory' | 'math';
}

const LeaderboardModal: React.FC<LeaderboardModalProps> = ({ isOpen, onClose, gameTitle, userScore, gameType }) => {
  const dummyPlayers = useMemo(() => {
    const names = ['ProGamer_99', 'DiamondKing', 'Speedy_ZZ', 'LogicMaster', 'Elite_FF', 'Shadow_Hunter', 'QueenBee', 'CyberPunk', 'Zenith', 'Flash_X'];
    
    let scores: number[] = [];
    if (gameType === 'tap') {
      scores = [45, 42, 38, 35, 30, 28, 25, 22, 18, 15];
    } else if (gameType === 'memory') {
      scores = [15, 18, 22, 25, 30, 35, 40, 45, 50, 60]; // Lower is better
    } else {
      scores = [5, 5, 5, 4, 4, 3, 3, 2, 2, 1];
    }

    const players: LeaderboardEntry[] = names.map((name, i) => ({
      name,
      score: scores[i]
    }));

    // Add user
    players.push({ name: 'YOU', score: userScore, isUser: true });

    // Sort
    if (gameType === 'memory') {
      return players.sort((a, b) => a.score - b.score);
    }
    return players.sort((a, b) => b.score - a.score);
  }, [gameType, userScore]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white w-full max-w-sm rounded-[2.5rem] overflow-hidden shadow-2xl animate-scaleUp flex flex-col max-h-[80vh]">
        <div className="diamond-gradient p-6 text-white flex justify-between items-center">
          <div>
            <h3 className="text-xl font-black italic tracking-tight">LEADERBOARD</h3>
            <p className="text-xs font-bold opacity-80 uppercase tracking-widest">{gameTitle}</p>
          </div>
          <button onClick={onClose} className="bg-white/20 p-2 rounded-xl hover:bg-white/30 transition-colors">
            <i className="fas fa-times"></i>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {dummyPlayers.map((player, index) => {
            const isTop3 = index < 3;
            const rankIcon = index === 0 ? 'fa-crown text-yellow-500' : index === 1 ? 'fa-medal text-gray-400' : index === 2 ? 'fa-medal text-orange-400' : null;

            return (
              <div 
                key={player.name + index}
                className={`flex items-center justify-between p-4 rounded-2xl border-2 transition-all ${
                  player.isUser 
                    ? 'border-indigo-500 bg-indigo-50 shadow-[0_0_15px_rgba(99,102,241,0.25)] scale-[1.02] z-10' 
                    : 'border-transparent bg-gray-50/50'
                }`}
              >
                <div className="flex items-center space-x-4">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-sm ${isTop3 ? 'bg-white shadow-sm' : 'text-gray-400'}`}>
                    {rankIcon ? <i className={`fas ${rankIcon}`}></i> : index + 1}
                  </div>
                  <div>
                    <p className={`font-bold ${player.isUser ? 'text-indigo-600' : 'text-gray-800'}`}>
                      {player.name}
                      {player.isUser && <span className="ml-2 text-[10px] bg-indigo-600 text-white px-2 py-0.5 rounded-full uppercase font-black">Your Rank</span>}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className={`font-black ${player.isUser ? 'text-indigo-700' : 'text-gray-800'}`}>
                    {player.score}
                    <span className="text-[10px] font-bold text-gray-400 ml-1 uppercase">
                      {gameType === 'memory' ? 'sec' : gameType === 'tap' ? 'taps' : 'pts'}
                    </span>
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        <div className="p-4 bg-gray-50 border-t border-gray-100 text-center">
          <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Compete daily to reach #1</p>
        </div>
      </div>
    </div>
  );
};

export default LeaderboardModal;
