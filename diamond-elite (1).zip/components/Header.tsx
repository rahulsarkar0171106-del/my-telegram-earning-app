
import React from 'react';

interface HeaderProps {
  diamonds: number;
  isSyncing?: boolean;
}

const Header: React.FC<HeaderProps> = ({ diamonds, isSyncing }) => {
  return (
    <header className="diamond-gradient text-white p-4 shadow-md sticky top-0 z-50 flex justify-between items-center rounded-b-3xl">
      <div className="flex items-center space-x-3">
        <div className="bg-white/20 p-2 rounded-xl relative group">
          <i className="fas fa-gem text-blue-200 text-xl animate-heartbeat group-hover:scale-110 transition-transform"></i>
          {isSyncing && (
            <div className="absolute -top-1 -right-1 flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-300 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-blue-400"></span>
            </div>
          )}
        </div>
        <div>
          <h1 className="text-lg font-bold tracking-tight leading-none">Diamond elite</h1>
          {isSyncing ? (
             <span className="text-[8px] font-black uppercase tracking-widest text-blue-200 animate-pulse">Syncing Cloud...</span>
          ) : (
             <span className="text-[8px] font-black uppercase tracking-widest text-white/60">Cloud Connected</span>
          )}
        </div>
      </div>
      <div className="bg-white/20 px-4 py-1.5 rounded-full flex items-center space-x-2 border border-white/30 backdrop-blur-sm animate-glow">
        <i className="fas fa-gem text-blue-300"></i>
        <span className="font-bold text-lg">{diamonds.toLocaleString()}</span>
      </div>
    </header>
  );
};

export default Header;
