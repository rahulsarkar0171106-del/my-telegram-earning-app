
export enum AppTab {
  HOME = 'home',
  SPIN = 'spin',
  SCRATCH = 'scratch',
  GAMES = 'games',
  WALLET = 'wallet',
  PROFILE = 'profile'
}

export interface User {
  name: string;
  email: string;
  photo: string;
  provider: 'google' | 'facebook';
  uid: string;
}

export interface UserState {
  diamonds: number;
  spinsRemaining: number;
  scratchCardsRemaining: number;
  gamesRemaining: number;
  lastDailyReset: string;
  highScores: {
    tap: number;
    memory: number; 
    math: number;
  };
  user: User | null;
  lastSync: string;
  cloudStorageUsed: number; // In KB
}

export interface LeaderboardEntry {
  name: string;
  score: number;
  isUser?: boolean;
}

export interface RewardOption {
  amount: number;
  type: 'diamonds' | 'empty';
  label: string;
}

export const SPIN_REWARDS: RewardOption[] = [
  { amount: 10, type: 'diamonds', label: '10' },
  { amount: 0, type: 'empty', label: '😭' },
  { amount: 20, type: 'diamonds', label: '20' },
  { amount: 40, type: 'diamonds', label: '40' },
  { amount: 15, type: 'diamonds', label: '15' },
  { amount: 0, type: 'empty', label: '😭' },
  { amount: 25, type: 'diamonds', label: '25' },
  { amount: 30, type: 'diamonds', label: '30' },
];
