
# 💎 Diamond Elite - Reward Application

Diamond Elite is a feature-rich, high-performance reward application where users can earn virtual diamonds through engaging activities like Lucky Spins, Scratch Cards, and Mini-Games.

## ✨ Key Features
- **Lucky Spin Wheel:** Test your luck and win diamonds daily.
- **Scratch Cards:** Interactive scratch-to-reveal prizes.
- **Mini Games:** 
  - *Diamond Tap:* Test your reaction speed.
  - *Memory Match:* Train your brain and find pairs.
  - *Math Quiz:* Solve fast-paced calculations.
- **Persistent Sessions:** Users stay logged in even after app restarts.
- **Offline Protection:** Gracefully handles internet connectivity issues.
- **Cloud-Simulated UI:** Real-time data synchronization indicators.
- **Responsive Design:** Optimized for mobile-first experience using Tailwind CSS.

## 🚀 Technical Stack
- **Frontend:** React, TypeScript
- **Styling:** Tailwind CSS, FontAwesome Icons
- **Persistence:** LocalStorage API with Session Management
- **Icons:** FontAwesome v6.4

## 📂 Project Structure
- `/components`: Modular UI components (Spin, Scratch, Games, etc.)
- `App.tsx`: Main application controller and state manager.
- `types.ts`: TypeScript interfaces and global constants.
- `index.html`: Main entry point with ES6 Module support.

## 🛠️ How to Run Locally
1. Clone the repository.
2. Ensure you have a static file server or use a modern browser that supports ES Modules.
3. Open `index.html` in your browser.

## 📝 Disclaimer
This app uses virtual points (Diamonds) for entertainment and simulation purposes. Real rewards and payouts are handled externally via specified support channels.

---
*Created with ❤️ by Diamond Elite Dev Team*
