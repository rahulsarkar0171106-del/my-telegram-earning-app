
import React, { useState, useEffect, useCallback } from 'react';
import { AppTab, UserState, User } from './types';
import Header from './components/Header';
import Home from './components/Home';
import LuckySpin from './components/LuckySpin';
import ScratchCards from './components/ScratchCards';
import Games from './components/Games';
import Wallet from './components/Wallet';
import Profile from './components/Profile';
import Auth from './components/Auth';
import Navigation from './components/Navigation';

const STORAGE_KEY_PREFIX = 'diamondly_prod_v1_';
const SESSION_KEY = 'diamondly_session_active';
const DAILY_SPIN_LIMIT = 100;
const DAILY_SCRATCH_LIMIT = 50;
const DAILY_GAMES_LIMIT = 25;

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<AppTab>(AppTab.HOME);
  const [isSyncing, setIsSyncing] = useState(false);
  const [userState, setUserState] = useState<UserState | null>(null);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isInitialLoading, setIsInitialLoading] = useState(true);

  // Sync Logic
  const syncWithStorage = useCallback((state: UserState) => {
    if (!state.user?.uid) return;
    const key = STORAGE_KEY_PREFIX + state.user.uid;
    localStorage.setItem(key, JSON.stringify(state));
  }, []);

  // Initialize Data
  const initUserData = useCallback((user: User): UserState => {
    const key = STORAGE_KEY_PREFIX + user.uid;
    const saved = localStorage.getItem(key);
    const today = new Date().toDateString();
    
    const defaultState: UserState = {
      diamonds: 0,
      spinsRemaining: DAILY_SPIN_LIMIT,
      scratchCardsRemaining: DAILY_SCRATCH_LIMIT,
      gamesRemaining: DAILY_GAMES_LIMIT,
      lastDailyReset: today,
      highScores: { tap: 0, memory: 999, math: 0 },
      user: user,
      lastSync: new Date().toISOString(),
      cloudStorageUsed: 0.12 
    };

    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.lastDailyReset !== today) {
          return {
            ...parsed,
            user,
            spinsRemaining: DAILY_SPIN_LIMIT,
            scratchCardsRemaining: DAILY_SCRATCH_LIMIT,
            gamesRemaining: DAILY_GAMES_LIMIT,
            lastDailyReset: today
          };
        }
        return { ...parsed, user };
      } catch (e) {
        return defaultState;
      }
    }
    return defaultState;
  }, []);

  // Check Session Persistence
  useEffect(() => {
    const restore = async () => {
      try {
        const activeUser = localStorage.getItem(SESSION_KEY);
        if (activeUser) {
          const user = JSON.parse(activeUser) as User;
          const state = initUserData(user);
          setUserState(state);
        }
      } catch (e) {
        localStorage.removeItem(SESSION_KEY);
      } finally {
        setTimeout(() => setIsInitialLoading(false), 1500);
      }
    };
    restore();

    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [initUserData]);

  // Global Sync Listener
  useEffect(() => {
    if (userState && isOnline) {
      const timer = setTimeout(() => {
        setIsSyncing(true);
        syncWithStorage(userState);
        setTimeout(() => setIsSyncing(false), 800);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [userState?.diamonds, userState?.spinsRemaining, isOnline, syncWithStorage]);

  const handleLogin = (user: User) => {
    localStorage.setItem(SESSION_KEY, JSON.stringify(user));
    const state = initUserData(user);
    setUserState(state);
  };

  const handleLogout = () => {
    if (window.confirm("আপনি কি লগআউট করতে চান? আপনার ডাটা এই ডিভাইসে সেভ থাকবে।")) {
      localStorage.removeItem(SESSION_KEY);
      setUserState(null);
      setActiveTab(AppTab.HOME);
    }
  };

  const addDiamonds = useCallback((amount: number) => {
    setUserState(prev => prev ? ({ ...prev, diamonds: prev.diamonds + amount }) : null);
  }, []);

  const useSpin = useCallback(() => {
    if (userState && userState.spinsRemaining > 0) {
      setUserState(prev => prev ? ({ ...prev, spinsRemaining: prev.spinsRemaining - 1 }) : null);
      return true;
    }
    return false;
  }, [userState]);

  const useScratch = useCallback(() => {
    if (userState && userState.scratchCardsRemaining > 0) {
      setUserState(prev => prev ? ({ ...prev, scratchCardsRemaining: prev.scratchCardsRemaining - 1 }) : null);
      return true;
    }
    return false;
  }, [userState]);

  const useGamePlay = useCallback(() => {
    if (userState && userState.gamesRemaining > 0) {
      setUserState(prev => prev ? ({ ...prev, gamesRemaining: prev.gamesRemaining - 1 }) : null);
      return true;
    }
    return false;
  }, [userState]);

  const updateHighScore = useCallback((game: keyof UserState['highScores'], score: number) => {
    setUserState(prev => {
      if (!prev) return null;
      let isBetter = false;
      if (game === 'memory') isBetter = score < prev.highScores.memory;
      else isBetter = score > prev.highScores[game];
      if (isBetter) return { ...prev, highScores: { ...prev.highScores, [game]: score } };
      return prev;
    });
  }, []);

  if (isInitialLoading) {
    return (
      <div className="flex flex-col min-h-screen items-center justify-center bg-[#050505] text-white p-6">
        <div className="relative mb-10">
          <div className="absolute inset-0 bg-indigo-500/30 blur-3xl rounded-full scale-150 animate-pulse"></div>
          <i className="fas fa-gem text-indigo-400 text-8xl animate-bounce"></i>
        </div>
        <div className="text-center">
          <h2 className="text-3xl font-black italic tracking-widest animate-pulse mb-3">DIAMOND ELITE</h2>
          <div className="flex items-center justify-center space-x-2 text-indigo-400/60 uppercase text-[10px] font-bold tracking-[0.3em]">
             <i className="fas fa-circle-notch animate-spin"></i>
             <span>Loading Secure Environment</span>
          </div>
        </div>
      </div>
    );
  }

  if (!userState) {
    return <Auth onLogin={handleLogin} />;
  }

  const renderTabContent = () => {
    switch (activeTab) {
      case AppTab.HOME: return <Home setActiveTab={setActiveTab} userState={userState} />;
      case AppTab.SPIN: return <LuckySpin addDiamonds={addDiamonds} useSpin={useSpin} userState={userState} />;
      case AppTab.SCRATCH: return <ScratchCards addDiamonds={addDiamonds} useScratch={useScratch} userState={userState} />;
      case AppTab.GAMES: return <Games addDiamonds={addDiamonds} useGamePlay={useGamePlay} userState={userState} updateHighScore={updateHighScore} />;
      case AppTab.WALLET: return <Wallet userState={userState} setUserState={setUserState as any} />;
      case AppTab.PROFILE: return <Profile userState={userState} setUserState={setUserState as any} onLogout={handleLogout} />;
      default: return <Home setActiveTab={setActiveTab} userState={userState} />;
    }
  };

  return (
    <div className="flex flex-col min-h-screen max-w-md mx-auto bg-white shadow-2xl relative overflow-hidden select-none">
      <Header diamonds={userState.diamonds} isSyncing={isSyncing} />
      
      <main className="flex-1 pb-24 overflow-y-auto bg-gray-50/30 relative z-10 page-transition pt-4 px-4">
        {renderTabContent()}
      </main>

      <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />

      {!isOnline && (
        <div className="fixed inset-0 z-[2000] bg-black/80 backdrop-blur-lg flex items-center justify-center p-8 text-center animate-fadeIn">
          <div className="bg-white p-8 rounded-[3rem] shadow-2xl animate-scaleUp">
            <i className="fas fa-wifi-slash text-red-500 text-5xl mb-6 animate-pulse"></i>
            <h2 className="text-2xl font-black text-gray-800 mb-2">No Connection!</h2>
            <p className="text-gray-500 text-sm mb-6">আপনার ইন্টারনেট কানেকশন চেক করুন। ডাটা সেভ করতে অ্যাপটি কানেকশন ছাড়া চলবে না।</p>
            <button onClick={() => window.location.reload()} className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold shadow-lg shadow-indigo-200">TRY AGAIN</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
